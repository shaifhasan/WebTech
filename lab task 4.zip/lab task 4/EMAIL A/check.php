<?php
	
	if(isset($_POST['email'])){
		echo $_POST['email'];
	}
?>