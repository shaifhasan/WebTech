

<form action="#" method="POST">
	<fieldset>
		<legend>EMAIL</legend>
		<input type="text" name="email" value="<?php
	
	if(isset($_POST['email'])){
		echo $_POST['email'];
	}
	
?>" ><img src="1.png" padding-left="1px" width="15px" height="20px"/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>