<?php
	
	if(isset($_POST['dd'])){
		echo $_POST['dd'];
	}
	if(isset($_POST['mm'])){
		echo $_POST['mm'];
	}

	if(isset($_POST['yy'])){
		echo $_POST['yy'];
	}
?>