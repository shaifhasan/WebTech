<?php
	
	if(isset($_POST['g'])){
		
		echo $_POST['g'];
		}
		if(isset($_POST['ga'])){
		
		echo $_POST['ga'];
		}
		if(isset($_POST['ge'])){
		
		echo $_POST['ge'];
		}
		if(isset($_POST['gr'])){
		
		echo $_POST['gr'];
		}
	
?>