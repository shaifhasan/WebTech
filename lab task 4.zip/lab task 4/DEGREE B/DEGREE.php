<?php
	
	if(isset($_POST['g'])){
		
		echo $_POST['g'];
		}
		if(isset($_POST['ga'])){
		
		echo $_POST['ga'];
		}
		if(isset($_POST['ge'])){
		
		echo $_POST['ge'];
		}
		if(isset($_POST['gr'])){
		
		echo $_POST['gr'];
		}
	
?>
<form action="#" method="POST">
	<fieldset>
		<legend>DEGREE</legend>
		<input type="checkbox" name="g" value="SSC" >SSC
		<input type="checkbox" name="ga" value="HSC" >HSC
		<input type="checkbox" name="ge" value="Bsc" >Bsc
		<input type="checkbox" name="gr" value="Msc" >Msc
		<br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>