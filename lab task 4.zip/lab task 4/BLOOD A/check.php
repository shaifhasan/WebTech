<?php
	
	if(isset($_POST['g'])){
		echo $_POST['g'];
	}
?>