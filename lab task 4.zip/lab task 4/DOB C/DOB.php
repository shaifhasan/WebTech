
	

	
<form action="#" method="post">
	<fieldset>
		<legend>DOB</legend>
		<pre style="margin-top: 0;margin-bottom:0 "> dd     mm     yyyy</pre>
		
		<input type="number" name="dd" style="width: 3em" value="<?php
	
	if(isset($_POST['dd'])){
		echo $_POST['dd'];
	} ?>">
	
		/
		<input type="number" name="mm" style="width: 3em" value="<?php if(isset($_POST['mm'])){
		echo $_POST['mm'];
	} ?>">
		/<input type="number" name="yy" style="width: 3em" value="<?php if(isset($_POST['yy'])){
		echo $_POST['yy'];
	}
?>">
		<br/>
		
		<input type="submit" name="submit" value="Submit">
	</fieldset>
</form>

