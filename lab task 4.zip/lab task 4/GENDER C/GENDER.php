
<form action="#" method="POST">
	<fieldset>
		<legend>GENDER</legend>
		<input type="radio" name="g" value="Male"<?php if($_POST['g']=="Male"){echo "Checked";}?> /> Male
		<input type="radio" name="g" value="Female"<?php if($_POST['g']=="Female"){echo "Checked";}?> /> Female
		<input type="radio" name="g" value="Other"<?php if($_POST['g']=="Other"){echo "Checked";}?>  /> Other
		<br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>