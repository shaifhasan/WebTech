<?php
	
	if(isset($_POST['Name'])){
		echo $_POST['Name'];
	}
?>