
<form action="#" method="POST">
	<fieldset>
		<legend>Name</legend>
		<input type="text" name="Name" value="<?php
	
	if(isset($_POST['Name'])){
		echo $_POST['Name'];
	}
?>" ><img src="1.png" padding-left="1px" width="15px" height="20px"/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>