<?php
	
	if(isset($_POST['dd'])){
		echo $_POST['dd'];
	}
	if(isset($_POST['mm'])){
		echo $_POST['mm'];
	}

	if(isset($_POST['yy'])){
		echo $_POST['yy'];
	}
?>
<form action="#" method="post">
	<fieldset>
		<legend>DOB</legend>
		<pre style="margin-top: 0;margin-bottom:0 "> dd     mm     yyyy</pre>
		
		<input type="number" name="dd" style="width: 3em">
	
		/
		<input type="number" name="mm" style="width: 3em">
		/<input type="number" name="yy" style="width: 3em">
		<br/>
		
		<input type="submit" name="submit" value="Submit">
	</fieldset>
</form>

