<?php
	
	if(isset($_POST['g'])){
		
		echo $_POST['g'];
		
		}
	
?>
<form action="#" method="POST">
	<fieldset>
		<legend>GENDER</legend>
		<input type="radio" name="g" value="Male" >Male
		<input type="radio" name="g" value="Female" >Female
		<input type="radio" name="g" value="Other" >Other
		<br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>