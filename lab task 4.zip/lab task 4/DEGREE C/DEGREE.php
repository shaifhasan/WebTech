<form action="#" method="POST">
	<fieldset>
		<legend>DEGREE</legend>
		<input type="checkbox" name="g" value="SSC"  <?php if(isset($_POST['g'])&&$_POST['g']=="SSC"){echo "Checked";} ?> />SSC
		<input type="checkbox" name="ga" value="HSC" <?php if(isset($_POST['ga'])&&$_POST['ga']=="HSC"){echo "Checked";} ?> />HSC
		<input type="checkbox" name="ge" value="Bsc" <?php if(isset($_POST['ge'])&&$_POST['ge']=="Bsc"){echo "Checked";} ?> />Bsc
		<input type="checkbox" name="gr" value="Msc" <?php if(isset($_POST['gr'])&&$_POST['gr']=="Msc"){echo "Checked";} ?> />Msc
		<br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>