
<?php error_reporting(0);?>
<form action="#" method="POST">
	<fieldset>
		<legend>GENDER</legend>
		<input type="radio" name="g" value="Male"<?php if($_POST['g']=="Male"){echo "Checked";} ?> /> Male
		<input type="radio" name="g" value="Female"<?php if($_POST['g']=="Female"){echo "Checked";} ?> /> Female
		<input type="radio" name="g" value="Other"<?php if($_POST['g']=="Other"){echo "Checked";} ?>  /> Other
		<?php
	   if(isset($_POST['submit']))
	   {

		if (empty($_POST["g"])) {
       echo "*Must select one"; } 
  	}
?>
		<br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>