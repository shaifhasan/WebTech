<form action="#" method="POST">
	<fieldset>
		<legend>DEGREE</legend>
		<input type="checkbox" name="g" value="SSC"  <?php if(isset($_POST['g'])&&$_POST['g']=="SSC"){echo "Checked";} ?> />SSC
		<input type="checkbox" name="ga" value="HSC" <?php if(isset($_POST['ga'])&&$_POST['ga']=="HSC"){echo "Checked";} ?> />HSC
		<input type="checkbox" name="ge" value="Bsc" <?php if(isset($_POST['ge'])&&$_POST['ge']=="Bsc"){echo "Checked";} ?> />Bsc
		<input type="checkbox" name="gr" value="Msc" <?php if(isset($_POST['gr'])&&$_POST['gr']=="Msc"){echo "Checked";} ?> />Msc
		<?php
		$count=0;
		if(isset($_POST['g'])){
		
		 if(isset($_POST['g'])&&$_POST['g']=="SSC")
		{
			$count=1;
		} 
		 if(isset($_POST['ga'])&&$_POST['ga']=="HSC")
		{
			$count=$count+1;
		} 
		 if(isset($_POST['ge'])&&$_POST['ge']=="Bsc")
		{
			$count=$count+1;
		} 
		if(isset($_POST['gr'])&&$_POST['gr']=="Msc")
		{
			$count=$count+1;
		} 
		
	}
	if($count<2&&isset($_POST['submit']))
		{
			echo "need to check at list two";
		}
	?>
		<br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>