

<form action="#" method="POST">
	<fieldset>
		<legend>EMAIL</legend>
		<input type="text" name="email" value="" ><img src="1.png" padding-left="1px" width="15px" height="20px"/><?php
	          
	if(isset($_POST['email'])){
		 $email=$_POST['email'];
		if (empty($_POST["email"])) {
       echo "*Email is required";
  } 
   else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      echo "*Invalid email format"; 
    }
		
	}
	
?><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>