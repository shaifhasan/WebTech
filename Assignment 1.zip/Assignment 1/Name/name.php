

<form action="#" method="POST">
	<fieldset>
		<legend>NAME</legend>
		<input type="text" name="name" value="" >
		<?php
	if(isset($_POST['name'])){
		$name=$_POST["name"];
	if (empty($_POST["name"])) {
    echo "*Name is required";
     }
    if (strlen($name)<2) {
    echo "*Must be two character";
     }
     if(!ctype_alpha($name[0]))
     {
     	echo "*Start Must be letters";
     }
     if(ctype_alnum($name))
     {
     	echo "*Number not allow";
     }
     if(strpos($name, "@"))
     {
     	echo "*Special character not allow";
     }
     if(strpos($name, "!"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, "$"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, "%"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, "^"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, "&"))
     {
     	echo "*Special character not allow";
     } if(strpos($name, "*"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, "("))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, ")"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, "_"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, "+"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, "-"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, "?"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, "<"))
     {
     	echo "*Special character not allow";
     }
      if(strpos($name, ">"))
     {
     	echo "*Special character not allow";
     }
	  }
	 ?>
<br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>
