<?php error_reporting(0);?>
<form action="#" method="post">
	<fieldset>
		<legend>DOB</legend>
		<pre style="margin-top: 0;margin-bottom:0 "> dd     mm     yyyy</pre>
		
		<input type="number" name="dd" style="width: 3em">
		<?php
	          
	if(isset($_POST['dd'])){
		$int=$_POST['dd'];
		 $min=1;
		 $max=31;
		if (empty($_POST["dd"])) {
       echo "*day is empty";
  } 
  if (filter_var($int, FILTER_VALIDATE_INT, array("options" => array("min_range"=>$min, "max_range"=>$max))) === false) {
    echo("value is not within the legal range");
}
		
	}
	
?>
		/
		<input type="number" name="mm" style="width: 3em">
		<?php
	          
	if(isset($_POST['mm'])){
		  $int=$_POST['mm'];
		 $min=1;
		 $max=12;
		if (empty($_POST["mm"])) {
       echo "*month is required";
  } 
  if (filter_var($int, FILTER_VALIDATE_INT, array("options" => array("min_range"=>$min, "max_range"=>$max))) === false) {
    echo("value is not within the legal range");
}
		
	}
	
?>
		/
		<input type="number" name="yy" style="width: 3em">
		<?php
	          
	if(isset($_POST['yy'])){
		$int=$_POST['yy'];
		 $min=1953;
		 $max=1998;
		if (empty($_POST["yy"])) {
       echo "*year is required";
  } 
  if (filter_var($int, FILTER_VALIDATE_INT, array("options" => array("min_range"=>$min, "max_range"=>$max))) === false) {
    echo("value is not within the legal range");
}
		
	}
	
?>

		<br/>
		
		<input type="submit" name="submit" value="Submit">
	</fieldset>
</form>

